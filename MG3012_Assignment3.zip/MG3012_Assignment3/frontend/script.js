const GANACHE_URL = "http://127.0.0.1:7545";
let provider, signer, board, voting;
const $ = (id) => document.getElementById(id);

function setStatus(text, type) {
  const s = $("status");
  s.textContent = text;
  s.className = "status " + (type || "");
}

// Load a Truffle artifact (served from build/contracts) and build an ethers Contract
async function loadContract(name) {
  const res = await fetch(name + ".json");
  if (!res.ok) throw new Error(name + ".json not found. Run `truffle migrate` first.");
  const art = await res.json();
  const ids = Object.keys(art.networks || {});
  if (!ids.length) throw new Error(name + " is not deployed. Run `truffle migrate --reset`.");
  const current = String((await provider.getNetwork()).chainId);
  // Ganache may report network id 5777 but chain id 1337, so fall back to the latest deployment
  const id = art.networks[current] ? current : ids[ids.length - 1];
  const address = art.networks[id].address;
  return new ethers.Contract(address, art.abi, signer);
}

async function connect() {
  try {
    if (window.ethereum) {
      provider = new ethers.BrowserProvider(window.ethereum);
      await provider.send("eth_requestAccounts", []);
      signer = await provider.getSigner();
    } else {
      provider = new ethers.JsonRpcProvider(GANACHE_URL);
      signer = await provider.getSigner(0);
    }
    const net = await provider.getNetwork();
    board = await loadContract("MessageBoard");
    voting = await loadContract("Voting");

    $("account").textContent = await signer.getAddress();
    $("network").textContent = "chainId " + net.chainId;
    $("contractAddr").textContent = await board.getAddress();
    $("connectBtn").textContent = "Connected";
    ["readBtn", "writeBtn", "resetBtn"].forEach((id) => ($(id).disabled = false));
    setStatus("Connected.", "ok");
    await readData();
    await renderCandidates();
  } catch (err) {
    setStatus("Connection failed: " + (err.shortMessage || err.message), "err");
  }
}

async function readData() {
  try {
    const [msg, last, count, owner] = await Promise.all([
      board.getMessage(), board.getLastUpdater(), board.getUpdateCount(), board.owner()
    ]);
    $("currentMsg").textContent = msg;
    $("lastUpdater").textContent = last;
    $("updateCount").textContent = count.toString();
    $("ownerAddr").textContent = owner;
  } catch (err) {
    setStatus("Read failed: " + (err.shortMessage || err.message), "err");
  }
}

async function sendTx(fn) {
  try {
    setStatus("Sending transaction...", "info");
    const tx = await fn();
    $("txHash").textContent = tx.hash;
    const receipt = await tx.wait();
    setStatus("Success! Confirmed in block " + receipt.blockNumber + " (gas used: " + receipt.gasUsed + ").", "ok");
    await readData();
    await renderCandidates();
    return true;
  } catch (err) {
    setStatus("Transaction failed: " + (err.reason || err.shortMessage || err.message), "err");
    return false;
  }
}

async function renderCandidates() {
  const list = $("candList");
  list.innerHTML = "";
  const count = Number(await voting.getCandidateCount());
  const voted = await voting.hasVoted(await signer.getAddress());
  for (let i = 0; i < count; i++) {
    const [name, votes] = await voting.getCandidate(i);
    const li = document.createElement("li");
    li.className = "cand";
    const span = document.createElement("span");
    span.textContent = name + " — " + votes + " vote(s)";
    const btn = document.createElement("button");
    btn.textContent = "Vote";
    btn.disabled = voted;
    btn.onclick = () => sendTx(() => voting.vote(i));
    li.append(span, btn);
    list.appendChild(li);
  }
}

$("connectBtn").addEventListener("click", connect);
$("readBtn").addEventListener("click", readData);
$("writeBtn").addEventListener("click", async () => {
  const text = $("newMsg").value.trim();
  if (!text) { setStatus("Please type a message first.", "err"); return; }
  if (await sendTx(() => board.setMessage(text))) $("newMsg").value = "";
});
$("resetBtn").addEventListener("click", () => sendTx(() => board.resetMessage()));

if (window.ethereum) {
  window.ethereum.on("accountsChanged", () => location.reload());
  window.ethereum.on("chainChanged", () => location.reload());
}
