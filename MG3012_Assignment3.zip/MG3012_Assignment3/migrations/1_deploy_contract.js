const MessageBoard = artifacts.require("MessageBoard");

module.exports = function (deployer) {
  // Constructor takes the initial message
  deployer.deploy(MessageBoard, "Hello Ganache");
};
