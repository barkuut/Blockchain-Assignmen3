// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title Voting - bonus second contract
/// @notice Owner registers candidates; each address may vote once.
contract Voting {
    address public owner;
    string[] private candidates;
    mapping(uint256 => uint256) public votes;
    mapping(address => bool) public hasVoted;

    event Voted(address indexed voter, uint256 indexed candidateId);

    constructor() {
        owner = msg.sender;
    }

    function addCandidate(string calldata _name) external {
        require(msg.sender == owner, "Only owner");
        require(bytes(_name).length > 0, "Name required");
        candidates.push(_name);
    }

    function vote(uint256 _candidateId) external {
        require(!hasVoted[msg.sender], "Already voted");
        require(_candidateId < candidates.length, "Invalid candidate");
        hasVoted[msg.sender] = true;
        votes[_candidateId] += 1;
        emit Voted(msg.sender, _candidateId);
    }

    function getCandidateCount() external view returns (uint256) {
        return candidates.length;
    }

    function getCandidate(uint256 _id) external view returns (string memory name, uint256 voteCount) {
        require(_id < candidates.length, "Invalid candidate");
        return (candidates[_id], votes[_id]);
    }
}
