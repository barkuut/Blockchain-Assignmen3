# MG3012 – Assignment 3: Smart Contracts with Truffle & Ganache

**Student:** Muhammad Bin Barkaat  
**Course:** MG3012 Blockchain Technology for Business (BSFT, Fall 2026)  
**Instructor:** Dr. Usama Arshad  
**GitHub:** _add your repo link_

A dApp deployed to a local Ganache blockchain with Truffle.

- `SmartContract.sol` – the `MessageBoard` contract from Assignment 2 (unchanged): anyone can `setMessage`, only the owner can `resetMessage`.
- `Voting.sol` – **bonus** second contract (owner-added candidates, one vote per address).
- `frontend/` – HTML/CSS/JS using ethers.js v6; works with MetaMask or directly with Ganache.

## Project structure
```
contracts/      SmartContract.sol, Voting.sol
migrations/     1_deploy_contract.js, 2_deploy_voting.js
test/           messageboard.test.js
frontend/       index.html, script.js, style.css
truffle-config.js, package.json, bs-config.json
screenshots/    compile, migrate, UI interaction
```

## Setup
1. Install Node.js (v16+), then:
   ```bash
   npm install -g truffle
   npm install            # installs lite-server for the frontend
   ```
2. Install **Ganache** (GUI from archive.trufflesuite.com/ganache, or CLI: `npx ganache --port 7545`).
   Start a workspace on `127.0.0.1:7545`. (If you use port 8545, edit `truffle-config.js`.)

## Commands
```bash
truffle version
truffle compile
truffle migrate --reset     # deploys both contracts to Ganache
truffle test                # runs the tests in test/
npm run dev                 # serves the frontend at http://localhost:3000
```
(`truffle init` was used to create the project skeleton; the contract from Assignment 2 sits in `contracts/`.)

## Testing the dApp
1. With Ganache running, run `truffle migrate --reset`, then `npm run dev`.
2. Open http://localhost:3000. Without MetaMask the page uses Ganache's first account automatically.
3. Read the message, update it, reset it (owner only, i.e. Ganache account 0), and vote for a candidate; each action is a transaction visible in Ganache's *Transactions* tab.
4. **Optional – MetaMask:** add a network with RPC `http://127.0.0.1:7545`, chain ID `1337` (Ganache CLI) or `5777` (older Ganache GUI), and import a private key from Ganache. Reload the page and approve the connection.

## Screenshots to capture (put in `screenshots/`)
`truffle compile`, `truffle migrate`, `truffle test`, Ganache showing blocks/transactions, the dApp after updating the message, and after voting.

## Troubleshooting
- *"has no deployments"* – run `truffle migrate --reset` first (the frontend reads `build/contracts/*.json`).
- *Invalid opcode / PUSH0 error* – the config pins Solidity 0.8.20 with the `paris` EVM for this reason.
- *Connection refused* – confirm Ganache's port matches `truffle-config.js` and `script.js`.
