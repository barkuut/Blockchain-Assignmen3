const MessageBoard = artifacts.require("MessageBoard");
const Voting = artifacts.require("Voting");

contract("MessageBoard", (accounts) => {
  it("deploys with the initial message and owner", async () => {
    const c = await MessageBoard.deployed();
    assert.equal(await c.getMessage(), "Hello Ganache");
    assert.equal(await c.owner(), accounts[0]);
  });

  it("lets anyone update the message", async () => {
    const c = await MessageBoard.deployed();
    await c.setMessage("Hi from Truffle", { from: accounts[1] });
    assert.equal(await c.getMessage(), "Hi from Truffle");
    assert.equal(await c.getLastUpdater(), accounts[1]);
    assert.equal((await c.getUpdateCount()).toString(), "1");
  });

  it("rejects empty and >140 char messages", async () => {
    const c = await MessageBoard.deployed();
    for (const [m, err] of [["", "Message cannot be empty"], ["x".repeat(141), "Max 140 characters"]]) {
      try { await c.setMessage(m); assert.fail("should revert"); }
      catch (e) { assert.include(e.message, err); }
    }
  });

  it("only the owner can reset", async () => {
    const c = await MessageBoard.deployed();
    try { await c.resetMessage({ from: accounts[1] }); assert.fail("should revert"); }
    catch (e) { assert.include(e.message, "Only owner can reset"); }
    await c.resetMessage({ from: accounts[0] });
    assert.equal(await c.getMessage(), "Message reset by owner");
  });
});

contract("Voting", (accounts) => {
  it("lets an account vote only once", async () => {
    const v = await Voting.deployed();
    await v.vote(1, { from: accounts[1] });
    const c = await v.getCandidate(1);
    assert.equal(c.voteCount.toString(), "1");
    try { await v.vote(1, { from: accounts[1] }); assert.fail("should revert"); }
    catch (e) { assert.include(e.message, "Already voted"); }
  });
});
