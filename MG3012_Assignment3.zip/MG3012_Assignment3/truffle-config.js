module.exports = {
  networks: {
    // Ganache GUI default: 127.0.0.1:7545. For ganache-cli/`npx ganache` use port 8545.
    development: {
      host: "127.0.0.1",
      port: 7545,
      network_id: "*",
    },
  },

  compilers: {
    solc: {
      version: "0.8.20",
      settings: {
        optimizer: { enabled: false, runs: 200 },
        evmVersion: "paris", // avoids PUSH0 which older Ganache versions reject
      },
    },
  },
};
